async function loadApp() {
  await import('./main.jsx');
}
loadApp();